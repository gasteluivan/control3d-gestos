import { ModelConfig } from './types';

export const MODELS: ModelConfig[] = [
  {
    id: 'TORUS_KNOT',
    name: 'Quantum Knot',
    description: 'A complex topological structure representing entangled states.',
    color: '#00ffff',
    roughness: 0.1,
    metalness: 0.9,
  },
  {
    id: 'ICOSAHEDRON',
    name: 'Core Crystal',
    description: 'A twenty-faced polyhedron synthesized from pure data.',
    color: '#ff00ff',
    roughness: 0.2,
    metalness: 0.8,
  },
  {
    id: 'OCTAHEDRON',
    name: 'Defense Matrix',
    description: 'Dual-pyramid structure used for system security visualizer.',
    color: '#ffff00',
    roughness: 0.1,
    metalness: 1.0,
  },
  {
    id: 'SPHERE_GRID',
    name: 'Neural Orb',
    description: 'Perfect spherical geometry with wireframe overlay.',
    color: '#00ffaa',
    roughness: 0.4,
    metalness: 0.6,
  },
  {
    id: 'MOTORCYCLE',
    name: 'Cyber Buggy',
    description: 'Advanced all-terrain reconnaissance vehicle with detailed mechanical texturing.',
    color: '#ffffff',
    roughness: 0.5,
    metalness: 0.5,
  },
];