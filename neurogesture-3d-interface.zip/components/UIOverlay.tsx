import React from 'react';
import { HandMetrics, ModelConfig } from '../types';
import { MODELS } from '../constants';
import { Scan, Box, Activity, Fingerprint, Aperture, Bike } from 'lucide-react';

interface UIOverlayProps {
  handData: HandMetrics;
  selectedModel: ModelConfig;
  onSelectModel: (model: ModelConfig) => void;
}

const UIOverlay: React.FC<UIOverlayProps> = ({ handData, selectedModel, onSelectModel }) => {
  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6">
      {/* HEADER */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]">
            NEURO<span className="text-white">GESTURE</span>
          </h1>
          <div className="flex items-center gap-2 mt-2 text-xs text-cyan-600">
            <Activity size={14} className="animate-pulse" />
            <span>SYSTEM ONLINE</span>
            <span className="w-1 h-1 bg-cyan-500 rounded-full mx-1"></span>
            <span>V 2.5.0</span>
          </div>
        </div>

        {/* STATUS INDICATOR */}
        <div className={`flex flex-col items-end transition-all duration-500 ${handData.isPresent ? 'opacity-100' : 'opacity-50'}`}>
            <div className="flex items-center gap-2 mb-1">
                <span className={`text-sm font-mono tracking-widest ${handData.isPresent ? 'text-green-400' : 'text-red-500'}`}>
                    {handData.isPresent ? 'LINK ESTABLISHED' : 'SEARCHING INPUT'}
                </span>
                <div className={`w-3 h-3 rounded-full ${handData.isPresent ? 'bg-green-500 shadow-[0_0_10px_#0f0]' : 'bg-red-500 animate-pulse'}`}></div>
            </div>
            
            {handData.isPresent && (
                <div className="bg-black/40 backdrop-blur-md border border-cyan-500/30 p-2 rounded text-[10px] font-mono text-cyan-200 w-48">
                    <div className="flex justify-between mb-1">
                        <span>ZOOM_LEVEL</span>
                        <div className="w-20 bg-gray-800 h-2 mt-1 rounded-full overflow-hidden">
                            <div className="h-full bg-cyan-400" style={{width: `${handData.openness * 100}%`}}></div>
                        </div>
                    </div>
                    <div className="flex justify-between mb-1">
                        <span>AXIS_TILT</span>
                        <span>{(handData.tilt * 57.29).toFixed(1)}°</span>
                    </div>
                    <div className="flex justify-between text-yellow-400 font-bold border-t border-white/10 pt-1 mt-1">
                        <span>MODE:</span>
                        <span>{handData.gesture}</span>
                    </div>
                </div>
            )}
        </div>
      </div>

      {/* CENTER GUIDES */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] border border-white/5 rounded-full pointer-events-none flex items-center justify-center">
         <div className="w-[480px] h-[480px] border border-cyan-500/10 rounded-full animate-spin-slow" style={{ animationDuration: '20s' }}></div>
         {handData.isPresent && (
             <div className="absolute w-full h-full flex items-center justify-center">
                 <Scan size={300} className="text-cyan-500/20 animate-pulse" />
             </div>
         )}
      </div>

      {/* FOOTER CONTROLS */}
      <div className="flex items-end justify-between w-full pointer-events-auto">
         {/* INSTRUCTIONS */}
         <div className="bg-black/60 backdrop-blur-xl border-l-2 border-cyan-500 p-4 max-w-sm rounded-r-lg">
             <h3 className="text-cyan-400 text-sm font-bold mb-2 flex items-center gap-2">
                 <Fingerprint size={16} /> CONTROL PROTOCOLS
             </h3>
             <ul className="text-xs text-gray-300 space-y-2 font-mono">
                 <li className="flex items-center gap-2">
                    <span className="w-1 h-1 bg-white rounded-full"></span>
                    <span className={handData.gesture === 'FIST' ? 'text-yellow-400 font-bold' : ''}>
                        FIST: Center & Rotate Object
                    </span>
                 </li>
                 <li className="flex items-center gap-2">
                    <span className="w-1 h-1 bg-white rounded-full"></span>
                    <span className={handData.gesture === 'OPEN_PALM' ? 'text-yellow-400 font-bold' : ''}>
                        OPEN HAND: Activate Zoom
                    </span>
                 </li>
                 <li className="flex items-center gap-2">
                    <span className="w-1 h-1 bg-white rounded-full"></span>
                    <span className={handData.gesture === 'TWO_FINGERS' ? 'text-yellow-400 font-bold' : ''}>
                        2 FINGERS: Tilt to Spin
                    </span>
                 </li>
                 <li className="flex items-center gap-2">
                    <span className="w-1 h-1 bg-white rounded-full"></span>
                    <span className={handData.gesture === 'THREE_FINGERS' ? 'text-yellow-400 font-bold' : ''}>
                        3 FINGERS: Drag to Rotate Y
                    </span>
                 </li>
             </ul>
         </div>

         {/* OBJECT SELECTOR CAROUSEL */}
         <div className="flex gap-4 overflow-x-auto pb-2 pl-4 max-w-2xl no-scrollbar mask-gradient-right">
             {MODELS.map((model) => (
                 <button
                    key={model.id}
                    onClick={() => onSelectModel(model)}
                    className={`
                        relative group flex flex-col items-center justify-center w-24 h-24 rounded-xl border backdrop-blur-sm transition-all duration-300
                        ${selectedModel.id === model.id 
                            ? 'bg-cyan-500/20 border-cyan-400 scale-110 shadow-[0_0_20px_rgba(34,211,238,0.3)]' 
                            : 'bg-white/5 border-white/10 hover:bg-white/10 hover:scale-105'}
                    `}
                 >
                    {selectedModel.id === model.id && (
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-cyan-400 rounded-full animate-ping"></div>
                    )}
                    
                    {model.id === 'TORUS_KNOT' && <Aperture size={24} className={selectedModel.id === model.id ? 'text-cyan-300' : 'text-gray-400'} />}
                    {model.id === 'ICOSAHEDRON' && <Box size={24} className={selectedModel.id === model.id ? 'text-cyan-300' : 'text-gray-400'} />}
                    {model.id === 'OCTAHEDRON' && <Scan size={24} className={selectedModel.id === model.id ? 'text-cyan-300' : 'text-gray-400'} />}
                    {model.id === 'SPHERE_GRID' && <Activity size={24} className={selectedModel.id === model.id ? 'text-cyan-300' : 'text-gray-400'} />}
                    {model.id === 'MOTORCYCLE' && <Bike size={24} className={selectedModel.id === model.id ? 'text-cyan-300' : 'text-gray-400'} />}
                    
                    <span className="text-[9px] mt-2 font-mono uppercase tracking-widest text-gray-300 group-hover:text-white">
                        {model.name.split(' ')[0]}
                    </span>
                 </button>
             ))}
         </div>
      </div>
      
      {/* CURRENT SELECTION DETAIL */}
      <div className="absolute bottom-32 right-6 max-w-xs text-right pointer-events-none">
          <h2 className="text-2xl font-bold text-white mb-1 uppercase">{selectedModel.name}</h2>
          <p className="text-xs text-cyan-200/80 font-mono leading-relaxed border-r-2 border-cyan-500/50 pr-3">
              {selectedModel.description}
          </p>
          <div className="mt-2 flex justify-end gap-1">
             <div className="h-1 w-8 bg-cyan-500"></div>
             <div className="h-1 w-4 bg-cyan-500/50"></div>
             <div className="h-1 w-2 bg-cyan-500/20"></div>
          </div>
      </div>

    </div>
  );
};

export default UIOverlay;