import React, { useEffect, useRef, useState } from 'react';
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';
import { HandMetrics } from '../types';
import { calculateAngle, distance, normalize } from '../utils/geometry';

interface HandTrackerProps {
  onHandUpdate: (data: HandMetrics) => void;
}

const HandTracker: React.FC<HandTrackerProps> = ({ onHandUpdate }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [loading, setLoading] = useState(true);
  const lastVideoTime = useRef(-1);
  // Initialize with null to satisfy strict argument check
  const requestRef = useRef<number | null>(null);
  const handLandmarkerRef = useRef<HandLandmarker | null>(null);

  useEffect(() => {
    const init = async () => {
      try {
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.0/wasm"
        );
        
        handLandmarkerRef.current = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
            delegate: "GPU"
          },
          runningMode: "VIDEO",
          numHands: 1
        });

        startWebcam();
      } catch (error) {
        console.error("Error initializing MediaPipe:", error);
        setLoading(false);
      }
    };

    init();

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const startWebcam = async () => {
    if (!videoRef.current) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, frameRate: { ideal: 60 } }
      });
      videoRef.current.srcObject = stream;
      videoRef.current.addEventListener('loadeddata', predictWebcam);
      setLoading(false);
    } catch (err) {
      console.error("Webcam error:", err);
    }
  };

  const predictWebcam = () => {
    if (!handLandmarkerRef.current || !videoRef.current) return;

    let startTimeMs = performance.now();
    if (videoRef.current.currentTime !== lastVideoTime.current) {
      lastVideoTime.current = videoRef.current.currentTime;
      
      const results = handLandmarkerRef.current.detectForVideo(videoRef.current, startTimeMs);

      if (results.landmarks && results.landmarks.length > 0) {
        const landmarks = results.landmarks[0]; // Get first hand

        // --- GESTURE LOGIC ---

        // 1. OPENNESS (Zoom)
        // Measure avg distance of fingertips (8, 12, 16, 20) to Wrist (0)
        // Normalized against the hand size (Wrist to Middle MCP (9))
        const wrist = landmarks[0];
        const middleMCP = landmarks[9];
        const handSize = distance(wrist, middleMCP); // Reference scale
        
        const tips = [8, 12, 16, 20];
        let totalTipDist = 0;
        tips.forEach(idx => totalTipDist += distance(wrist, landmarks[idx]));
        const avgTipDist = totalTipDist / 4;
        
        // Empirically, fist is ~0.8 * handSize, Open is ~2.0 * handSize
        const rawOpenness = avgTipDist / handSize;
        const openness = normalize(rawOpenness, 0.8, 1.8);

        // 2. FIST ROTATION & TILT
        // Angle between Wrist(0) and Middle MCP(9) relative to Y-axis
        // Note: Camera X is mirrored usually.
        // We calculate angle relative to -PI/2 (upright)
        const angle = calculateAngle(wrist, middleMCP); 
        // Normalize angle so straight up is 0
        // In screen coords: Up is -90 deg (-PI/2).
        let tilt = angle + (Math.PI / 2);

        // 3. FINGER CONFIGURATION
        const isTipExtended = (tipIdx: number, mcpIdx: number) => {
             return distance(wrist, landmarks[tipIdx]) > distance(wrist, landmarks[mcpIdx]) * 1.5;
        };
        
        const indexOut = isTipExtended(8, 5);
        const middleOut = isTipExtended(12, 9);
        const ringOut = isTipExtended(16, 13);
        const pinkyOut = isTipExtended(20, 17);

        let gesture: HandMetrics['gesture'] = 'NONE';
        
        // Base state on openness
        if (openness > 0.8) {
            gesture = 'OPEN_PALM';
        } else if (openness < 0.2) {
            gesture = 'FIST';
        }

        // Override with specific finger combos
        // 2 Fingers: Index & Middle
        if (indexOut && middleOut && !ringOut && !pinkyOut) {
            gesture = 'TWO_FINGERS';
        } 
        // 3 Fingers: Index, Middle & Ring
        else if (indexOut && middleOut && ringOut && !pinkyOut) {
            gesture = 'THREE_FINGERS';
        }

        onHandUpdate({
          isPresent: true,
          openness,
          tilt, // in radians
          position: {
            x: -(landmarks[9].x - 0.5) * 2, // Center 0, range -1 to 1. Invert X for mirror feel
            y: -(landmarks[9].y - 0.5) * 2  // Center 0, invert Y (screen y is down)
          },
          gesture
        });
      } else {
        onHandUpdate({ isPresent: false, openness: 0, tilt: 0, position: { x: 0, y: 0 }, gesture: 'NONE' });
      }
    }

    requestRef.current = requestAnimationFrame(predictWebcam);
  };

  return (
    <div className="absolute top-4 left-4 z-50 pointer-events-none opacity-40 hover:opacity-100 transition-opacity">
       {/* Debug view - keeping it small and technological */}
      <div className="relative border border-cyan-500/30 rounded-lg overflow-hidden bg-black/50 backdrop-blur-md p-1 w-32 h-24">
        {loading && <div className="absolute inset-0 flex items-center justify-center text-[10px] text-cyan-400 animate-pulse">INIT SENSORS...</div>}
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          muted 
          className={`w-full h-full object-cover transform -scale-x-100 ${loading ? 'opacity-0' : 'opacity-100'}`} 
        />
        <div className="absolute bottom-0 left-0 w-full h-1 bg-cyan-900">
           <div className="h-full bg-cyan-400 transition-all duration-300" style={{ width: loading ? '0%' : '100%' }}></div>
        </div>
      </div>
    </div>
  );
};

export default HandTracker;