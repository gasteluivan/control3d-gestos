import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh, Vector3, Euler } from 'three';
import { TorusKnot, Icosahedron, Octahedron, Sphere, MeshDistortMaterial, Environment, Float, Stars, useGLTF } from '@react-three/drei';
import { HandMetrics, ModelConfig } from '../types';

// Augment JSX namespace to fix missing intrinsic element types in this environment
declare global {
  namespace JSX {
    interface IntrinsicElements {
      group: any;
      ambientLight: any;
      pointLight: any;
      meshStandardMaterial: any;
      color: any;
      primitive: any;
    }
  }
}

interface ExperienceProps {
  handData: HandMetrics;
  selectedModel: ModelConfig;
}

// Reliable public URL for a Buggy model (GLB Binary) from Khronos Group samples
const MODEL_URL = "https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Buggy/glTF-Binary/Buggy.glb";

const Experience: React.FC<ExperienceProps> = ({ handData, selectedModel }) => {
  const meshRef = useRef<any>(null);
  
  // Conditional load: only load if MOTORCYCLE is selected to save bandwidth, 
  // or always load if we want instant switch.
  // Note: useGLTF suspends.
  const gltf = useGLTF(MODEL_URL);
  
  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // --- AUTO ROTATION DEFAULT ---
    if (!handData.isPresent) {
      // Default idle animation
      meshRef.current.rotation.y += delta * 0.5;
      meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.2;
      
      // Reset scale gently
      const baseScale = selectedModel.id === 'MOTORCYCLE' ? 0.02 : 1; 
      meshRef.current.scale.lerp(new Vector3(baseScale, baseScale, baseScale), delta * 2);
      return;
    }

    // --- INTERACTIVE MODE ---

    // 1. ZOOM (Openness)
    const baseScale = selectedModel.id === 'MOTORCYCLE' ? 0.02 : 1;
    const maxScale = baseScale * 2.5;
    
    // Fist (0) -> Scale 1 (Center)
    // Open (1) -> Scale 2.5 (Zoom In)
    const targetS = baseScale + (handData.openness * (maxScale - baseScale));
    meshRef.current.scale.lerp(new Vector3(targetS, targetS, targetS), delta * 5);


    // 2. ROTATION LOGIC
    if (handData.gesture === 'THREE_FINGERS') {
      // 3 FINGERS: Manual Turntable Control
      // Move hand Left/Right to precisely rotate the object on Y axis.
      // position.x is -1 to 1. We map this to -PI to PI (full rotation)
      const targetY = handData.position.x * Math.PI;
      
      // Smooth interpolation to the target angle
      meshRef.current.rotation.y += (targetY - meshRef.current.rotation.y) * delta * 5;

    } else if (handData.gesture === 'TWO_FINGERS') {
      // 2 FINGERS: Velocity Spin
      // Tilt hand to spin object left or right
      const rotationSpeed = handData.tilt * 2; 
      // Inverted rotation direction as requested
      meshRef.current.rotation.y -= rotationSpeed * delta * 5;

    } else if (handData.gesture === 'FIST' || handData.gesture === 'NONE') {
      // FIST: Look At Hand
      const targetZ = -handData.tilt;
      const targetY = handData.position.x * 2; 
      const targetX = -handData.position.y * 2; 

      meshRef.current.rotation.z += (targetZ - meshRef.current.rotation.z) * delta * 5;
      meshRef.current.rotation.y += (targetY - meshRef.current.rotation.y) * delta * 5;
      meshRef.current.rotation.x += (targetX - meshRef.current.rotation.x) * delta * 5;
    } else {
        // Just Open Palm - gentle idle spin while zooming
        meshRef.current.rotation.y += delta * 0.2;
    }
  });

  const Material = useMemo(() => {
     return (
        <MeshDistortMaterial
          color={selectedModel.color}
          envMapIntensity={1}
          clearcoat={1}
          clearcoatRoughness={0.1}
          metalness={selectedModel.metalness}
          roughness={selectedModel.roughness}
          distort={0.4}
          speed={2}
        />
     )
  }, [selectedModel]);

  // Clone scene for safety
  const modelScene = useMemo(() => gltf.scene.clone(), [gltf.scene]);

  return (
    <>
      <color attach="background" args={['#050505']} />
      
      <Environment preset="city" />
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      
      {/* Lights */}
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#00ffff" />
      <pointLight position={[-10, -10, -10]} intensity={1} color="#ff00ff" />

      <Float speed={2} rotationIntensity={0.2} floatIntensity={0.5}>
        <group rotation={[0,0,0]}>
            {selectedModel.id === 'TORUS_KNOT' && (
                <TorusKnot ref={meshRef} args={[1, 0.3, 128, 16]}>
                    {Material}
                </TorusKnot>
            )}
            {selectedModel.id === 'ICOSAHEDRON' && (
                <Icosahedron ref={meshRef} args={[1.5, 0]}>
                    {Material}
                </Icosahedron>
            )}
            {selectedModel.id === 'OCTAHEDRON' && (
                <Octahedron ref={meshRef} args={[1.5, 0]}>
                     {Material}
                </Octahedron>
            )}
            {selectedModel.id === 'SPHERE_GRID' && (
                <Sphere ref={meshRef} args={[1.5, 32, 32]}>
                     <meshStandardMaterial wireframe color={selectedModel.color} emissive={selectedModel.color} emissiveIntensity={0.5} />
                </Sphere>
            )}
            {selectedModel.id === 'MOTORCYCLE' && (
                <primitive 
                    ref={meshRef} 
                    object={modelScene} 
                    // Initial rotation/scale will be handled by useFrame, but set defaults here
                    rotation={[0, -Math.PI / 2, 0]} 
                />
            )}
        </group>
      </Float>
    </>
  );
};

export default Experience;