import React, { useState, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { HandMetrics, ModelConfig } from './types';
import { MODELS } from './constants';
import Experience from './components/Experience';
import HandTracker from './components/HandTracker';
import UIOverlay from './components/UIOverlay';
import { ErrorBoundary } from './components/ErrorBoundary';
import { AlertTriangle } from 'lucide-react';

const FallbackComponent = () => (
  <mesh>
    <boxGeometry args={[1, 1, 1]} />
    <meshStandardMaterial color="red" wireframe />
  </mesh>
);

const App: React.FC = () => {
  const [handData, setHandData] = useState<HandMetrics>({
    isPresent: false,
    openness: 0,
    tilt: 0,
    position: { x: 0, y: 0 },
    gesture: 'NONE'
  });

  const [selectedModel, setSelectedModel] = useState<ModelConfig>(MODELS[0]);

  return (
    <div className="relative w-full h-screen bg-[#050505] overflow-hidden">
      
      {/* 1. Computer Vision Layer */}
      <HandTracker onHandUpdate={setHandData} />

      {/* 2. 3D Render Layer */}
      <div className="absolute inset-0 z-0">
        <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
          <Suspense fallback={null}>
            <ErrorBoundary fallback={<FallbackComponent />}>
              <Experience 
                  handData={handData} 
                  selectedModel={selectedModel} 
              />
            </ErrorBoundary>
          </Suspense>
        </Canvas>
      </div>

      {/* 3. UI Layer */}
      <div className="absolute inset-0 z-10">
        <UIOverlay 
            handData={handData} 
            selectedModel={selectedModel}
            onSelectModel={setSelectedModel}
        />
      </div>

      {/* Decorative background grid */}
      <div 
        className="absolute inset-0 z-[-1] pointer-events-none opacity-20"
        style={{
            backgroundImage: `linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
        }}
      ></div>
    </div>
  );
};

export default App;