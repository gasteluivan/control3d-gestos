export interface HandMetrics {
  isPresent: boolean;
  openness: number; // 0 (fist) to 1 (flat palm)
  tilt: number; // Radians, roll of the hand
  position: { x: number; y: number }; // Normalized -1 to 1
  gesture: 'NONE' | 'FIST' | 'OPEN_PALM' | 'TWO_FINGERS' | 'THREE_FINGERS';
}

export type ModelType = 'TORUS_KNOT' | 'ICOSAHEDRON' | 'OCTAHEDRON' | 'SPHERE_GRID' | 'MOTORCYCLE';

export interface ModelConfig {
  id: ModelType;
  name: string;
  description: string;
  color: string;
  roughness: number;
  metalness: number;
}