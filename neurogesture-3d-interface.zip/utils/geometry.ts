// Simple vector math helpers
export const distance = (p1: { x: number; y: number }, p2: { x: number; y: number }) => {
  return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
};

export const calculateAngle = (p1: { x: number; y: number }, p2: { x: number; y: number }) => {
  return Math.atan2(p2.y - p1.y, p2.x - p1.x);
};

export const normalize = (val: number, min: number, max: number) => {
  return Math.max(0, Math.min(1, (val - min) / (max - min)));
};
